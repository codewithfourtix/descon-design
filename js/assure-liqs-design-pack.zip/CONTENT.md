# CONTENT.md — words and numbers

## Voice

Plain, specific, calm. These are engineers; they want the fact, not encouragement.

- **Sentence case everywhere.** Headings, buttons, labels. The only uppercase is the 11px
  group label.
- **No exclamation marks. No emoji. No "Oops".**
- **Say the consequence.** *Batch held pending re-sample* beats *Status: Non-conforming*.
- **Name the thing.** *Biuret rising 6 samples running* beats *Trend anomaly detected*.
- **Second person for actions**, impersonal for facts: "Awaiting your approval" / "3 missed".

## Numbers

| Rule | Example |
| --- | --- |
| Always with a unit | `168 ppm`, not `168` |
| Mono face, tabular figures | every measured value, ID, time, count |
| Keep the method's decimal places | `46.32%`, not `46.3%` |
| Fractions for progress | `9 / 16`, not `56%` alone |
| Ratio against limit, spelled | `168 ppm against 150 max` |
| Spec limits as written | `46.0 min`, `1.00 max`, `0.40–0.50` |
| No thousands separators below 10,000 | `9500` |

## Dates and times

- **24-hour clock**, always: `14:00`, `06:00–14:00`. Plant shifts are named by 24-hour spans.
- **Dates:** `15 Nov 2026` in prose, `15/11/2026` where space is tight. Never US order.
- **Relative where it helps:** `handover 2 h ago`, `1 h 05 m late`, `due in 3 days`.
- **Always say as-of:** `as of 13:55`, `Synced 14:02`. A dense data screen without a
  freshness stamp is untrustworthy.

## Labels

| Prefer | Not |
| --- | --- |
| Awaiting your approval | Pending items |
| Samples not taken | Missed sampling events |
| Parameters needing a look | Parameter status overview |
| Out of spec — batch held | Non-conformance |
| Out of trend — investigate before it fails | Warning |
| Queue clear. Nothing waiting on you. | No data available |
| Saved as you type | Autosave enabled |

## Buttons

Verb plus object, and carry the count when there is one.

- `Approve 6 selected`
- `Log CAPA`
- `Open schedule`
- `Save and come back`
- Avoid: `Submit`, `OK`, `Continue`, `Click here`

## Empty states

One sentence stating the fact, plus an action only if one genuinely exists.

- `Queue clear. Nothing waiting on you.`
- `No samples due before 22:00.`
- Never an illustration, never an apology.

## Errors and validation

Say what is wrong and what the limit was, inline, as it is typed.

- `Above 150 — out of spec`
- `Below 46.0 — out of spec`
- `Instrument KJ-07 is out of calibration — results cannot be approved`

Never a modal for a field-level problem. Never validate only on submit.

## Language

English throughout. English is the working language of Pakistani engineering and all method
documentation here is in English. Do not localise to Urdu unless explicitly asked; mixed-script
UI would make the technical vocabulary harder, not easier.

Keyboard hints use `Ctrl`, never `⌘` — these are Windows desktops.
