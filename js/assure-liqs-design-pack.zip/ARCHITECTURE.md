# ARCHITECTURE.md — structure

## Page skeleton

Every application screen is the same three-part frame. Do not invent a new one.

```
┌────────────┬──────────────────────────────────────────────┐
│            │  Top bar            60px, surface, border-b  │
│  Sidebar   ├──────────────────────────────────────────────┤
│  240px     │  Tab row            46px, surface, border-b  │
│  surface   ├──────────────────────────────────────────────┤
│  border-r  │                                              │
│            │  Content   padding 28px 32px, max-width 1400 │
│            │  sections stacked, gap 32px                  │
│            │                                              │
│            ├──────────────────────────────────────────────┤
│  User      │                                              │
└────────────┴──────────────────────────────────────────────┘
```

### Sidebar — 240px, fixed

Logo block, then navigation groups. Each group is an 11px uppercase label followed by
items. Active item: `accent` text, `accent-soft` background, weight 600.

Counts sit right-aligned in `muted` as plain numbers. **No filled badges.**

Order reflects the plant, not the software: Plant streams · Quality · Lab · Operations.
User identity pinned to the bottom above a hairline.

### Top bar — 60px

Search field on the left (with a `Ctrl K` key cap — these are Windows machines, never `⌘`),
status and identity on the right. No page title here; the title lives in the content.

### Tab row — the workspace tabs

Underlined, never pills. Active tab: `ink` text, weight 600, 2px `accent` bottom border,
`margin-bottom: -1px` so it sits on the row's own border. Inactive: `muted`, transparent
2px border.

Tabs for a plant stream are fixed: Dashboard · Result Entry · Finished Goods · Quality & OOS ·
Certificate · Non-Routine. At most one carries a count, and only when it is non-zero.

### Content

Sections stacked vertically, `gap: 32px`, `max-width: 1400px`.
Each section is an optional 14px heading followed by its content.

---

## Layout system

Flex and grid only. No floats, no absolute positioning for layout.

**The shell** is a wrapping flex row so it collapses on narrow screens:

```html
<div style="display: flex; flex-wrap: wrap; align-items: stretch; min-height: 100vh">
  <nav  style="flex: 0 0 240px">…</nav>
  <main style="flex: 999 1 560px; min-width: 0">…</main>
</div>
```

`flex: 999 1 560px` on the main column plus `flex-wrap` means the sidebar stacks above the
content below ~800px without a media query. `min-width: 0` is load-bearing — without it,
tables refuse to shrink and the layout overflows.

**Card grids** use `auto-fit` so they reflow without breakpoints:

```css
display: grid;
grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
gap: 16px;
```

Minimums by content: metric tiles `190px`, two-up regions `380px`, columns inside a single
card `320px`.

**Wide tables** go in `overflow-x: auto` with a `min-width` on the table.

### Widths to design against

| Width | Context | Must hold |
| --- | --- | --- |
| 1366 | The common plant-floor desktop. **Design here.** | Nothing truncates; tiles stay ≥3 per row. |
| 1440 | Reference frame. | — |
| 1920 | Manager's monitor. | `max-width: 1400` stops the line length running away. |
| <800 | Rare; tablet at the bench. | Sidebar stacks, tiles go one-up, tables scroll. |

---

## Composition rules

1. **Vary proportion.** A column of full-width bands reads as a wall. Mix a wide element
   with a two-up row, and give one element real presence.
2. **One element with substance per screen.** A chart, a worksheet, a large figure.
   A screen built only from small cards feels inert.
3. **Reading order is priority order.** What needs action first, reference last.
4. **Never state a number twice** on one screen.

---

## The real codebase

The shipped application is **vanilla HTML, CSS and JavaScript** — no framework, no bundler,
roughly 400 KB across ~20 modules.

```
index.html          shell: sidebar, top bar, content mount
css/styles.css      all styles; CSS custom properties at :root
js/app.js           hash router — #route or #route:tab
js/data*.js         data layer
js/screens/*.js     one module per screen, returns an HTML string
js/ui.js            shared helpers (tables, CSV export, toasts)
```

Routing is `location.hash`: `#urea:labsheet` is stream `urea`, tab `labsheet`.
Screens are string-returning functions, re-rendered on route change.

**When adding a screen:** add a `js/screens/<name>.js` exporting a render function, register
it in the router, add tokens to `:root` rather than hard-coding hex values, and keep
`font-variant-numeric: tabular-nums` on any numeric cell.

**Dependencies** are Chart.js and Lucide via CDN. If you are working offline, vendor them —
the app otherwise renders without icons or charts.
