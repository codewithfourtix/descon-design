# Screen A — annotated walkthrough

`screen-a.html` is the canonical reference. When a rule in the other files is ambiguous,
match this file.

## About the file format

It is an artboard from a design canvas, so it carries a thin wrapper:

- `<x-dc>` wraps the markup
- `<helmet>` holds the font link and the few CSS rules that cannot be inline
- `{{token}}` holes read from `renderVals()` in the `<script type="text/x-dc">` block
- `<sc-for list="{{items}}" as="item">` repeats, `<sc-if value="{{flag}}">` branches

**Everything else is ordinary HTML and inline CSS.** Strip the wrapper and you have a
static page. Port it to the real codebase by moving the inline styles into `css/styles.css`
and the `renderVals()` data into `js/data*.js`.

---

## What the screen is

**Urea → Dashboard**, seen by a QC manager two hours into the evening shift.

It answers one question: *what needs me right now?* Everything on it earns its place against
that question, which is why there is no month-to-date reporting on it.

## Reading order, and why

### 1. Page head — `Urea` + shift line + three figures

20px title, 12px muted line carrying shift, span, date and how long since handover. Shift
context is the frame for everything below; a plant runs 24 hours and "today" is not a useful
unit.

The three figures on the right are deliberately unlabelled boxes — no card, no fill. They sit
on the page background. This is hierarchy by scale and position, not by container.

### 2. Needs you now — one card, three columns

Three concerns (approvals, exceptions, overdue) inside **one** surface divided by hairlines,
not three separate cards. One object reads more calmly than three competing ones.

Each column: a dot, a sentence-case title, a count pushed right, then rows separated by
hairlines, then one action link.

The dot colours are the only colour in this region — blue for routine work, red for a real
breach, amber for schedule slippage.

### 3. Parameter health — six tiles

Small multiples. The whole point is comparison at a glance, so the tiles are identical in
size and structure; the *strokes* differ, not the surfaces.

Four parameters are in control and drawn in neutral grey. Biuret is amber because it has
risen six samples running — Nelson rule 3, still inside spec. Free NH₃ is red because it is
out of spec. Two coloured lines among six grey ones is enough to pull the eye.

The sparkline scales to its own data, including the spec limit only when it is near enough
to matter. The earlier version scaled every tile to include its limit and four of the six
collapsed into flat lines — see `COMPONENTS.md`.

### 4. Reference — adherence table and instruments

Last, because it is reference rather than action. Numbers right-aligned, tabular, with real
fractions (`9 / 16`) rather than percentages alone, so a reader can see both the rate and
the size.

The instruments card ends with a line of consequence: *a result recorded on an
out-of-calibration instrument cannot be approved*. That is the fact an operator needs, and
it is why the card exists.

---

## Decisions worth preserving

**The sidebar is white, not navy.** An earlier version used a dark rail. On a dense light
screen a dark block of that size fights everything beside it. The active item carries the
colour instead.

**Tabs are underlined, not pills.** Six filled pills sit on screen permanently and compete
with content. An underline marks position without adding another shape.

**No shadows.** Separation comes from a 1px border against a slightly tinted page.

**Counts in the nav are plain muted digits**, not filled badges. A badge is a shout; most of
these numbers do not warrant one.

**Nothing is stated twice.** An earlier version had the exception count in the page head, in
a card header and in a tab badge — three appearances of the number 2 within 200px, which
reads as three separate problems.

---

## Things in this file that should not be copied

- Two stray font sizes — `11.5` and `12.5`. Collapse to `11` and `12`.
- The `density` prop is a canvas-authoring convenience; it is not part of the design system.
- Mock names and sample IDs are illustrative. Keep the *format* (`URE-2612`), replace the
  content.
