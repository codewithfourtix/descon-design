# DESIGN.md — principles

These are ordered by how often they are violated. The first four prevent the majority of
bad screens.

---

## 1. Hierarchy comes from scale, space and position — never from colour

If something must dominate, make it **bigger**, give it **more room**, and put it **first**.
Do not give it a coloured background.

A tinted panel does not create importance; it creates noise, and it fights every surface
around it. This was learned the hard way on this product: a dark navy banner across the top
of a light page, then later a pink alert card, both read as damage rather than emphasis.

> **Rule:** at most one element per screen is more than 1.4× the size of its neighbours.
> That element is the focal point. Everything else is uniform.

**Do:** 24px figure beside 13px labels, 32px padding where others have 20px, placed top-left.
**Do not:** a red card, a gradient, a coloured left border, a filled badge row.

## 2. One accent. Status colours only where there is status

`#0060b0` is the accent. It means *interactive* — links, the active nav item, primary buttons,
focus rings. Nothing else is blue.

Red, amber and green are **status**, not decoration. They appear only on an element that
reports a real condition, and never more than a handful of times per screen. If the same
red number appears in a page header, in a card, and in a tab badge, a reader sees three
different problems. Say it once.

## 3. Borders only where a surface genuinely ends

A card gets one border. Things inside a card are separated by **space**, or at most a
hairline — not by more boxes. Cards inside cards are the most common cause of a screen
feeling cluttered.

Count the rectangles on your screen. If it is more than about eight, you are nesting.

## 4. Six type sizes. Three weights. No exceptions

Shipping ten sizes where three of them differ by half a pixel is invisible individually and
obvious collectively. See `STYLES.md` for the scale. If a new size feels necessary, the
layout is wrong, not the scale.

## 5. Figures are the product

This is a measurement system. Set every measured value, ID, timestamp, count and ratio in
the monospaced face with tabular figures. `46.32`, `0.94`, `168 ppm`, `9 / 16` should read as
instrument output, not as prose. It also makes columns align for free.

## 6. Density is a feature. Congestion is not

Chemical engineers read dense tables comfortably and resent oversized consumer dashboards.
But density means *more information per screen*, not *more furniture per screen*.

When a screen feels congested, the fix is almost never to shrink things. It is to **remove**
things: collapse the four healthy parameters into one line so the two that need attention
can breathe; drop the management-reporting table from the operator's screen entirely.

## 7. Every screen answers one question

Name it before you draw. A shift-control dashboard answers *what needs me right now*.
A result-entry worksheet answers *where do I type*. If an element does not serve the screen's
question, it belongs on a different screen.

## 8. Count the clicks

These users repeat the same action forty times a shift. Six approvals must not cost six
clicks: give them selection and one bulk action. Make whole rows the hit target, not just
the control inside them. Prefer inline editing to a modal, and autosave to a save button.

## 9. No AI tropes

Specifically banned: gradient washes, left-border accent cards, emoji in UI, filled pill
badges on everything, drop shadows used as decoration, hero sections with centred marketing
copy, and "✨" anywhere.

## 10. State the consequence, not the status

`Out of spec` is a status. *Batch held pending re-sample. No certificate can be issued for
this lot* is a consequence, and it is what the reader actually needs. Where there is room,
write what happens next.

---

## Anti-patterns observed on this product

| Symptom | Real cause | Fix |
| --- | --- | --- |
| "Looks off" | Ten type sizes, four weights | Collapse to the scale |
| "Feels heavy" | A dark or tinted full-width block | Remove the fill; keep the content |
| "Not lively" | Every module the same size, all full width | Vary proportion; add one element with real presence |
| "Congested" | Three stacked cards in a narrow column | Fewer, wider blocks |
| "Looks generated" | Uppercase micro-labels on every group, filled chips everywhere | Sentence case; dots and plain text |
| Same number three times | Summary strip duplicating card headers | Pick one location |
