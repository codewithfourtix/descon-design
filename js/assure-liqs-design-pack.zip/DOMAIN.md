# DOMAIN.md — lab rules that constrain the UI

**Read this before drawing anything that displays a measurement.** These are not styling
preferences. Getting them wrong produces screens that a process engineer will dismiss in
seconds, and some of them are compliance failures.

---

## 1. Specification limits and control limits are different things

The single most important rule in this product.

- **Specification limits** come from the customer and the grade. They answer *is this
  product saleable?*
- **Control limits** are computed from the process's own historical variation, at three
  sigma. They answer *is the process behaving as it normally does?*

Control limits sit **inside** the spec limits for a capable process. The gap between them is
the early-warning window, and it is the entire value proposition of the product.

**Never** draw control limits wider than the spec band. A chart showing a Biuret spec of
`1.00 max` with control limits at 35 and 65 is nonsense and destroys credibility instantly.

Correct example: spec `1.00 max`, mean `0.790`, UCL `0.925`, LCL `0.655`.

Limits are computed from a baseline period and **frozen**. Never silently recompute them on
a rolling window — the limits would widen as the process degrades and the chart would never
alarm.

## 2. Out of spec and out of trend are different events

| | Out of specification (OOS) | Out of trend (OOT) |
| --- | --- | --- |
| Means | A limit was breached | The process changed; still in spec |
| Problem type | Product | Process |
| Urgency | Immediate — material exists and must be held | Investigate |
| Colour | `critical` | `warning` |

A screen that only surfaces OOS has thrown away the point of SPC. Show both, differently.

## 3. Run rules

Patterns inside the limits that still signal a change. The useful ones:

| Rule | Pattern | Usually means |
| --- | --- | --- |
| 1 | One point beyond 3σ | A single disturbance |
| 2 | Nine points one side of centre | The mean has shifted |
| 3 | **Six points trending one way** | Drift — fouling, depletion, dosing slip |
| 5 | Two of three beyond 2σ, same side | A shift, caught early |

Rule 3 is the one this product exists to catch. Say which rule fired — *"Biuret rising 6
samples running"* — not just "anomaly detected".

## 4. Units are not decoration

`ppm` and `%` differ by a factor of 10,000. Always render the unit beside the value, and
always carry it in the data. Never let a UI show a bare number for a measured quantity.

Typical units here: `% w/w`, `ppm`, `µS/cm`, `mg/L`, `kg`, `°C`.

## 5. A blank is not a zero

An empty result cell can mean five different things, and they are not interchangeable:

- not required for this grade
- required and missed
- test still running (stability takes ~24 h)
- run, not yet entered
- below the detection limit

Render an explicit qualifier — `Not tested`, `Pending`, `< LOD` — never an empty cell and
never `0`.

## 6. Some results arrive a day late

Stability is an accelerated test: hold at ~96 °C, re-assay, report percentage retained. It
lands roughly 24 hours after every other parameter on the same sample.

So a sample is **partially complete** for a day. Any UI that assumes all parameters land
together is wrong. Design for a pending row that fills in later.

## 7. Some values are calculated, not measured

Active oxygen is a fixed ratio of concentration — `AO ≈ assay × 0.4704`. A 35% product is
16.5% AO; a 50% product is 23.5%.

Calculated fields are shown differently from entered ones and are never editable. Cooling
tower saturation indices (Langelier, Ryznar) are likewise derived from five inputs.

## 8. Results are append-only

ISO/IEC 17025 §7.5.2 requires that the original observation is retained alongside any
amendment, with the change traceable. A corrected value is a **new record**, not an edit.

The UI must therefore show *who, when, and why* for any change, and must never present a
value as though it had always been that.

## 9. A certificate is immutable

A Certificate of Analysis is a legal document relied on by the customer and, under a letter
of credit, by their bank. Once issued it cannot be edited — only reissued, visibly, with a
reason. It must be reproducible years later exactly as issued.

Never put an inline edit control on an issued certificate.

## 10. Parameters are configuration, not columns

The parameter list differs per grade and per sampling point. A hydrogen peroxide product has
concentration, active oxygen, stability, free acid, TOC, conductivity. Urea has total
nitrogen, biuret, moisture, free ammonia, crush strength, formaldehyde.

Never hard-code a fixed set of parameter columns.

## 11. Shift is a first-class attribute

The plant runs 24 hours. Shifts: Morning `06:00–14:00`, Evening `14:00–22:00`,
Night `22:00–06:00`, plus General `09:00–17:00`.

Every screen shows which shift it is reporting. "Since handover" is more useful than "today".
When a chart shows a pattern, *which shift* is the first question anyone asks.

---

## Reference values for realistic mock data

**Urea** — Total nitrogen `46.0% min` · Biuret `1.00% max` · Moisture `0.50% max` ·
Free NH₃ `150 ppm max` · Crush strength `2.50 kg min` · Formaldehyde `0.40–0.50%`

**Hydrogen peroxide (50% grade)** — Concentration `49.0–50.5% w/w` · Active oxygen
`23.1% min` · Stability `98% min` · Free acid `300 ppm max` · TOC `200 ppm max` ·
Conductivity `80 µS/cm max`

Sampling points: Pool reactor · Stripper outlet · Prill tower · Process condensate ·
Feed CO₂ · Working solution · Cooling tower basin.

Sample IDs: `URE-2612`, `HP-01`. Do not invent a different format.
