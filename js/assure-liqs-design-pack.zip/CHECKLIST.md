# CHECKLIST.md

Run this before calling a screen done. Most failures are in the first section.

## Type and colour

- [ ] Six font sizes or fewer, all from the scale: `11 · 12 · 13 · 14 · 20 · 24`
- [ ] Three weights only: `400 · 500 · 600`
- [ ] Every measured value, ID, timestamp and count is in the mono face with tabular figures
- [ ] Exactly one accent colour, and it means *interactive*
- [ ] Red and amber appear only on something reporting a real condition — count them; more
      than five instances is too many
- [ ] No tinted or dark full-width blocks
- [ ] Uppercase appears only on 11px group labels

## Structure

- [ ] Fewer than about eight bordered rectangles
- [ ] No card inside a card
- [ ] Separators inside a card use the hairline `#f1f4f8`, not the border token
- [ ] One element has clear presence; the rest are uniform
- [ ] Section gaps are 32px, card padding 20–24px, all spacing on the 4px rhythm
- [ ] No shadows (or one, at `0 1px 2px rgba(34,40,47,0.04)`)

## Information

- [ ] No number appears twice on the screen
- [ ] The screen answers one named question; nothing present fails to serve it
- [ ] There is an as-of timestamp
- [ ] Every status carries a word, not just a colour
- [ ] Consequences are stated, not just statuses

## Interaction

- [ ] A repeated action has a bulk path — *n* items never costs *n* clicks
- [ ] Whole rows are hit targets, not just the control inside
- [ ] Targets are ≥44px
- [ ] Validation is inline and immediate, not on submit
- [ ] Keyboard path exists and is visible on screen
- [ ] `Ctrl`, not `⌘`

## Domain

- [ ] Control limits sit inside spec limits, and are labelled as different things
- [ ] OOS and OOT are visually and verbally distinct
- [ ] Every measured value carries its unit
- [ ] No blank cells standing in for a qualifier
- [ ] Calculated fields are distinguishable from entered ones and are not editable
- [ ] Sparklines are scaled to their data, not flattened by a distant limit
- [ ] Shift context is on screen

## Accessibility

- [ ] All text ≥4.5:1; nothing lighter than `#8a95a5` carries words
- [ ] `#e0930b` used only as a dot, never as text
- [ ] Real `<button>`, `<a>`, `<input>`, `<label>`, `<th scope>`
- [ ] No `role` or `onClick` on a `div` or `span`
- [ ] `aria-current="page"` on active nav and tab
- [ ] Decorative SVG hidden; meaningful SVG labelled with its finding
- [ ] Visible focus on everything interactive

## Layout

- [ ] Holds at 1366 with nothing truncated
- [ ] `min-width: 0` on flex children containing tables
- [ ] Wide tables wrapped in `overflow-x: auto`
- [ ] Sidebar stacks rather than squashing below ~800px
- [ ] `max-width: 1400px` on content

---

## The three questions

If the screen still feels wrong and the boxes are all ticked, it is almost certainly one of:

1. **Too many type sizes.** Count them again.
2. **Colour doing a job that belongs to scale.** Remove every fill and see what is left.
3. **Everything the same weight.** Nothing dominates, so the eye has nowhere to land.
