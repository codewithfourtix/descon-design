# Assure LIQS — Design Pack

A complete specification of the Assure LIQS interface, written so an agent can read it
and produce new screens that look as though the same person designed them.

**Product:** Assure LIQS — a laboratory information and quality system for Descon Oxychem,
a hydrogen peroxide and urea producer in Sheikhupura, Pakistan.
**Users:** lab analysts on rotating shifts, QC managers, process engineers.
Pakistani chemical engineers working in English on Windows desktops, often 1366×768.

---

## Read in this order

| File | What it gives you |
| --- | --- |
| `DESIGN.md` | The principles. Read this first and do not skip it — it is the difference between a screen that looks designed and one that looks generated. |
| `STYLES.md` | Exact tokens: colour, type, spacing, radius, state. Copy values from here, never invent them. |
| `COMPONENTS.md` | Every component with its anatomy, sizes and variants. |
| `ARCHITECTURE.md` | Page skeleton, layout system, breakpoints, and how this maps to the real codebase. |
| `DOMAIN.md` | **Lab rules that change what you are allowed to draw.** Read before designing anything that shows a measurement. |
| `CONTENT.md` | Microcopy, number formatting, units, dates, empty states. |
| `ACCESSIBILITY.md` | Contrast, targets, semantics. Non-negotiable. |
| `CHECKLIST.md` | Run through this before you call a screen done. |
| `tokens.json` | The same tokens, machine-readable. |
| `reference/screen-a.html` | A complete, working reference screen. When in doubt, match it. |
| `reference/walkthrough.md` | Annotated tour of that screen and why each decision was made. |

---

## The one-paragraph brief

Assure LIQS is a dense data product for people who use it for eight hours at a stretch.
It should feel like an instrument, not a dashboard template: quiet surfaces, one accent,
figures set in a monospaced face so they read as measurements, and hierarchy created by
**scale and space rather than colour**. Information density is a feature for this audience —
but density is not congestion. Every screen answers a specific question its user arrived
with, and everything that does not serve that question is removed rather than shrunk.

## What "stunning and minimal" means here

It does not mean sparse. It means **nothing arbitrary**. Every size comes from a six-step
scale, every space from a 4px rhythm, every colour from a list of eleven. When a screen
looks wrong, the cause is almost always one of: too many type sizes, too many bordered
boxes, or colour being asked to do a job that belongs to scale.
