# ACCESSIBILITY.md

Non-negotiable. A screen that fails any of these is not finished.

## Contrast

- Body and label text: **≥ 4.5:1**. `muted` `#8a95a5` on white is 4.6:1 — that is the floor.
  Nothing lighter carries words.
- Large text (24px+ or 19px bold): ≥ 3:1.
- Status text uses the darker `-text` tokens. `#e0930b` is 2.6:1 on white and is a **dot
  colour only**.
- Do not reduce contrast to make a screen feel calmer. Low contrast makes the eye work
  harder, not less. Calm comes from the background value, type size and spacing.

## Colour is never the only signal

Every status carries a dot **and** a word: *Out of spec*, *Drifting up*, *In control*.
A reader with a colour vision deficiency, or a glance at a sunlit screen, must get the same
information.

Prefer blue/amber/red over green/red pairings, and make sure the colours differ in
lightness, not only hue.

## Targets

- Interactive targets **≥ 44px** including surrounding row padding. Analysts wear gloves.
- Make whole rows the target: wrap a selectable row in a `<label>`, not just the 17px
  checkbox.
- Minimum 8px between adjacent targets.

## Semantics

Use the real element, even in a static mockup:

- `<button type="button">` for actions, `<a href>` for navigation
- `<input>` paired with a `<label>` or carrying `aria-label`
- `<table>` with `<th scope="col">` and `<th scope="row">`
- `<nav aria-label="…">`, `<section aria-label="…">`, `<main>`, `<header>`
- `aria-current="page"` on the active nav item and active tab

**Never** put `role` or `onClick` on a `div` or `span` — the keyboard skips it.

## Icons and graphics

- Decorative SVG: `aria-hidden="true"`
- Meaningful SVG: `role="img"` plus a real `aria-label` that states the finding —
  *"Biuret trend over the last 14 results — drifting up"*, not *"chart"*
- Icon-only buttons always get an `aria-label`

## Focus

Visible on every interactive element:

```css
border-color: #0060b0;
box-shadow: 0 0 0 3px rgba(0, 96, 176, 0.14);
```

Never `outline: none` without a replacement. Tab order follows reading order.

## Keyboard

For repeated work, the mouse must be optional:

- `Tab` moves between fields in reading order
- `Ctrl K` opens search
- Document the shortcuts on screen, in `muted` 12px — people do not read manuals

## Motion

Minimal. No autoplay, no parallax, no animated counters. If a transition exists, keep it
under 150ms and respect `prefers-reduced-motion`.
