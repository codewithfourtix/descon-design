# COMPONENTS.md

Anatomy and exact values. Copy these rather than approximating.

---

## Card

The only container. One border, one radius, no shadow.

```html
<div style="background: #ffffff; border: 1px solid #e9edf2; border-radius: 10px; overflow: hidden">
```

Padding `20px 24px`, or `14px 16px` compact. Separators **inside** a card are
`1px solid #f1f4f8` — the hairline, never the border token.

A card never contains another card. Divide with space or a hairline.

## Section heading

```html
<h2 style="margin: 0 0 12px; font-size: 14px; font-weight: 600; color: #0f1b2d; letter-spacing: -0.01em">
```

Optionally followed by 12px `muted` context on the same baseline, and an action link
pushed right with `margin-left: auto`.

## Page title

20px / 600 / `-0.02em`, `ink`. One per screen, with a 12px `muted` line under it carrying
shift, date and freshness.

## Nav item

```
padding: 8px; border-radius: 6px; font-size: 13px; color: #475467
hover:  background #f4f7fa
active: color #0060b0; background #eef4fb; font-weight 600; aria-current="page"
```

Counts: right-aligned, 12px, `muted`, plain digits.

## Tab

```
padding: 13px 0; font-size: 13px; border-bottom: 2px solid transparent; margin-bottom: -1px
inactive: color #8a95a5
active:   color #0f1b2d; font-weight 600; border-bottom-color #0060b0; aria-current="page"
hover:    color #0f1b2d; border-bottom-color #d4dde8
```

Count badge, only when non-zero: 11.5px, `critical-text` on `critical-soft`, radius 10, padding `1px 6px`.

## Buttons

| Variant | Spec |
| --- | --- |
| Primary | `background #0060b0; color #fff; font-size 13px; weight 500; padding 9px 16px; radius 7px; border 0` |
| Secondary | `background #fff; color #475467; border 1px solid #e9edf2; padding 9px 15px; radius 7px` |
| Row action | `background #fff; color #0060b0; border 1px solid #e9edf2; font-size 12px; padding 5px 11px; radius 6px` |
| Disabled-ish | Primary with `#9fb8d2` fill. Keep it focusable; explain why in adjacent text. |

Always a real `<button type="button">` or `<a href>`. Never a div with onClick.

## Metric

```html
<div class="n" style="font-size: 24px; font-weight: 600; color: #0f1b2d; line-height: 1; letter-spacing: -0.02em">14</div>
<div style="font-size: 12px; color: #8a95a5; margin-top: 6px">Results in</div>
```

Figure above, label below. Never the reverse. Figure in the mono face.

## Status indicator

A 6–8px dot plus plain text. **Not** a filled pill.

```html
<span style="width: 7px; height: 7px; border-radius: 50%; background: #e11f26; display: inline-block"></span>
<span style="font-size: 12px; color: #c1121a">Out of spec — batch held</span>
```

Dot uses the `-mark` token, text uses the `-text` token. The text must carry the meaning on
its own — colour is never the only signal.

## Metric tile

Interactive card, `190px` minimum. Anatomy top to bottom:

1. Parameter name — 13px `body`, truncate with ellipsis
2. Value + unit — 24px mono `ink`, 12px `muted` unit
3. Sparkline — 36px tall, full width
4. Footer row — status dot, status text, spec limit pushed right in 11.5px `muted`

Hover: `border-color: #d4dde8`.

## Sparkline

`viewBox="0 0 140 36"`, `preserveAspectRatio="none"`, `width="100%"`.

- Series: 1.5px stroke. `neutral-line` when in control, `warning-mark` when drifting,
  `critical-mark` when out of spec.
- Last point: filled circle, `r=3`.
- Spec limit: 1px dashed `#dce3eb`, `stroke-dasharray="3 3"`.

**Scale to the data, not to the limit.** Include the limit in the scale only when it falls
within one data-range of the readings; otherwise omit the line entirely. A distant limit
flattens the series into a straight line and destroys the thing the tile exists to show.

```js
const range = dMax - dMin;
const near  = limit <= dMax + range && limit >= dMin - range;
```

## Table

```
header: 11px / 600 / 0.08em / uppercase / #8a95a5, background #fbfcfd, padding 12px 16px
cell:   13px, padding 15px 20px, border-top 1px solid #f1f4f8
row hover: #fafbfd
```

Numeric columns: right-aligned, mono, tabular. Row labels use `<th scope="row">`.
Wrap in `overflow-x: auto` with a `min-width`.

## Selectable row with bulk action

For any list where the same action is repeated. Six approvals must cost one click.

- Toolbar: select-all checkbox, live "`n` of `m` selected", Clear, primary bulk button
  carrying the count — *Approve 6 selected*.
- Each row is a `<label>` so the whole row toggles, not just the 17px box.
- Selected row background `#f7fafd`.
- Bulk button greys to `#9fb8d2` at zero selection.

## Progress bar

```html
<div style="height: 6px; border-radius: 3px; background: #e9edf2; overflow: hidden" role="presentation">
  <div style="width: 56%; height: 100%; background: #0060b0; border-radius: 3px"></div>
</div>
```

Always paired with the fraction in figures above it — `9 / 16`, not just a bar.

## Numeric input

```
height 42px; padding 0 14px; font-size 16px; weight 500; tabular figures
border 1px solid #d4dde8; radius 8px
focus: border #0060b0 + 3px rgba(0,96,176,.14) ring
placeholder: "—" in #b6bfcc
```

Validate inline as the value is typed. On breach: row background `#fdf6f6` and a Check
column naming the breach — *Above 150 — out of spec*. Never validate only on submit.

## Empty state

One sentence, `muted`, 13px, centred, ~28px vertical padding. State the fact, not an
apology: *Queue clear. Nothing waiting on you.* No illustration, no emoji, no button unless
there is genuinely an action.

## Key cap

```html
<kbd style="font-family: inherit; font-size: 11px; color: #8a95a5; border: 1px solid #e9edf2; border-radius: 4px; padding: 1px 5px">Ctrl K</kbd>
```

`Ctrl`, never `⌘`.
