# STYLES.md — tokens

Every value here is taken from the reference screen. Use these literally. If a value you
need is not here, you are solving the wrong problem.

---

## Colour

### Surfaces

| Token | Value | Use |
| --- | --- | --- |
| `page` | `#fbfcfd` | The app background. Everything sits on this. |
| `surface` | `#ffffff` | Cards, nav, top bar, tab row. |
| `surface-sunk` | `#fbfcfd` | Table headers, card footers, the search field. |
| `row-hover` | `#fafbfd` | Table and list row hover. |
| `nav-hover` | `#f4f7fa` | Sidebar item hover. |

### Lines

| Token | Value | Use |
| --- | --- | --- |
| `border` | `#e9edf2` | Card edges, dividers between regions, input borders. |
| `hairline` | `#f1f4f8` | Separators **inside** a card. Never use `border` there. |
| `border-strong` | `#d4dde8` | Hover state on an interactive card; chart gridlines. |

### Text

| Token | Value | Contrast on `#ffffff` | Use |
| --- | --- | --- | --- |
| `ink` | `#0f1b2d` | 16.1:1 | Headings, figures, primary row text. |
| `body` | `#475467` | 8.6:1 | Body copy, secondary table cells. |
| `muted` | `#8a95a5` | 4.6:1 | Labels, meta, units, placeholder-level text. **Floor — nothing lighter carries text.** |

### Accent — interactive only

| Token | Value | Use |
| --- | --- | --- |
| `accent` | `#0060b0` | Links, active nav, primary button fill, focus ring, active tab underline. |
| `accent-hover` | `#004c8c` | Link and button hover. |
| `accent-soft` | `#eef4fb` | Active nav background, avatar chip, soft badge. |

### Status — only on something that reports a condition

| Token | Value | Use |
| --- | --- | --- |
| `critical-text` | `#c1121a` | Out-of-spec values, blocked states, critical counts. |
| `critical-mark` | `#e11f26` | 6–8px dots, the brand mark. Never text. |
| `critical-soft` | `#fdf2f2` | Badge background. Use rarely. |
| `warning-text` | `#8a5a00` | Out-of-trend, overdue, due-soon. |
| `warning-mark` | `#e0930b` | Dots and sparkline strokes. Never text — fails contrast. |
| `positive` | `#17804a` | Synced indicator, in-spec confirmation. |
| `neutral-line` | `#7a899c` | Sparkline stroke for an in-control parameter. |

> Red and amber **text** tokens are darker than their dot tokens on purpose. `#e0930b` is
> 2.6:1 on white and must never carry words.

---

## Type

**Family:** Inter — `400`, `500`, `600`. Loaded from Google Fonts.
Stack: `Inter, system-ui, sans-serif`.

**For figures:** `'IBM Plex Mono', ui-monospace, monospace` with
`font-variant-numeric: tabular-nums`. Applied via a `.n` class to every measured value, ID,
timestamp, count and ratio.

### The scale — six sizes

| px | Weight | Letter-spacing | Use |
| --- | --- | --- | --- |
| `11` | 600 | `0.08em`, uppercase | Nav group labels, table column headers. The only uppercase in the system. |
| `12` | 400 | — | Meta: timestamps, units, spec limits, helper text. |
| `13` | 400 / 500 | — | Body. Nav items, table cells, list rows. |
| `14` | 600 | `-0.01em` | Section headings. |
| `20` | 600 | `-0.02em` | Page title. One per screen. |
| `24` | 600 | `-0.02em` | Metric figures. |

Line-height: `1.5` body, `1.25` headings, `1` on large figures.

> The reference screen still contains two strays — `11.5` and `12.5`. Collapse them to
> `11` and `12`. Do not propagate them.

---

## Spacing — 4px rhythm

Permitted: `4 · 6 · 8 · 10 · 12 · 16 · 20 · 24 · 32`

| Context | Value |
| --- | --- |
| Page padding | `28px 32px` |
| Gap between sections | `32px` |
| Card padding | `20px 24px` |
| Compact card padding | `14px 16px` |
| Row vertical padding | `12px` (list) / `15px` (table) |
| Gap between cards in a grid | `16px` (tiles) / `24px` (regions) |
| Icon-to-label gap | `8px` |
| Label-to-value gap | `6px` |

## Radius

| Value | Use |
| --- | --- |
| `6px` | Nav items. |
| `7px` | Buttons, inputs, small controls. |
| `10px` | Cards and panels. |
| `50%` | Status dots, avatars. |

Nothing else. No `4px`, no `16px`, no pills except a count badge.

## Elevation

**None.** Screen A uses no shadows. Separation comes from the border and the page
background. If you need a shadow, you are probably nesting cards.

The low-glare variant adds exactly one: `0 1px 2px rgba(34, 40, 47, 0.04)`. That is the
ceiling.

## Focus

```css
outline: none;
border-color: #0060b0;
box-shadow: 0 0 0 3px rgba(0, 96, 176, 0.14);
```

Never remove focus without replacing it.

## Controls

| Control | Height | Padding | Notes |
| --- | --- | --- | --- |
| Primary button | 38px | `9px 16px` | `accent` fill, white text, weight 500. |
| Secondary button | 38px | `9px 15px` | White fill, `border`, `body` text. |
| Input | 38–42px | `0 14px` | 16px tabular figures for numeric entry. |
| Search field | 34–38px | `0 12px` | `surface-sunk` fill, `border`. |
| Checkbox | 17px | — | `accent-color: #0060b0`. |
| Tap target | **≥44px** | — | Including the row around a control. |
